<html>
<head>
    <meta charset="utf-8">
   <link href="style.css" rel="stylesheet">
   <title>Team 3</title>
      <table align="center">
         <tr>
            <td align="center" valign="middle" style="font-family: 'Helvetica Neue', sans-serif; font-weight: bold; letter-spacing: -1px; line-height: 1;font-size: 35pt; color:#129EF7;">
            Information of App Store : Proposal for Delveloper</td>
            <td><img src="https://image.flaticon.com/icons/svg/831/831276.svg" width="70px"></td>
         </tr>
      </table>
</head>


<body style="background: #DEF6FE;">
   <div>
   <form name="form_check" method="post" action="team3.php" align="center">
    <br>
    <table align="center">
      <tr align="center">
        <td align="center">
    <fieldset>
      <label><input type="checkbox" class="selectAllMembers"/>Select All</label><br/>
        <label> <input type="checkbox" class='memberChk' name="category[]" value="book">Book&nbsp&nbsp&nbsp&nbsp&nbsp&nbsp&nbsp</label>
        <label> <input type="checkbox" class='memberChk' name="category[]" value="business" >Business&nbsp&nbsp&nbsp&nbsp&nbsp</label>
        <label> <input type="checkbox" class='memberChk' name="category[]" value="developertool">Delveloper Tool&nbsp&nbsp&nbsp</label>
        <label> <input type="checkbox" class='memberChk' name="category[]" value="education">Education&nbsp&nbsp&nbsp&nbsp&nbsp&nbsp&nbsp</label>
        <label> <input type="checkbox" class='memberChk' name="category[]" value="entertainment">Entertainment<br></label>
        <label> <input type="checkbox" class='memberChk' name="category[]" value="finance">Finance&nbsp&nbsp&nbsp&nbsp&nbsp&nbsp&nbsp</label>
        <label> <input type="checkbox" class='memberChk' name="category[]" value="food">Food & Beverage&nbsp&nbsp</label>
        <label> <input type="checkbox" class='memberChk' name="category[]" value="game">Game&nbsp&nbsp&nbsp&nbsp&nbsp&nbsp&nbsp</label>
        <label> <input type="checkbox" class='memberChk' name="category[]" value="graphic_design">Graphic & Design</label>
        <label> <input type="checkbox" class='memberChk' name="category[]" value="fitness">Health & Fitness</label>
        <label> <input type="checkbox" class='memberChk' name="category[]" value="lifestyle">Lifestyle<br></label>
        <label> <input type="checkbox" class='memberChk' name="category[]" value="magazine">Magazine&nbsp&nbsp</label>
        <label> <input type="checkbox" class='memberChk' name="category[]" value="medical">Medical&nbsp&nbsp&nbsp&nbsp&nbsp&nbsp&nbsp</label>
        <label> <input type="checkbox" class='memberChk' name="category[]" value="music">Music&nbsp&nbsp&nbsp&nbsp&nbsp&nbsp&nbsp</label>
        <label> <input type="checkbox" class='memberChk' name="category[]" value="navigation">Nevigation&nbsp&nbsp&nbsp&nbsp</label>
        <label> <input type="checkbox" class='memberChk' name="category[]" value="news">News&nbsp&nbsp&nbsp&nbsp&nbsp&nbsp&nbsp</label>
        <label> <input type="checkbox" class='memberChk' name="category[]" value="picture">Picture & Video&nbsp<br></label>
        <label> <input type="checkbox" class='memberChk' name="category[]" value="productivity">Productivity&nbsp&nbsp&nbsp&nbsp&nbsp&nbsp</label>
        <label> <input type="checkbox" class='memberChk' name="category[]" value="reference">Reference&nbsp&nbsp&nbsp&nbsp&nbsp&nbsp&nbsp</label>
        <label> <input type="checkbox" class='memberChk' name="category[]" value="shopping">Shopping&nbsp&nbsp&nbsp&nbsp&nbsp&nbsp&nbsp</label>
        <label> <input type="checkbox" class='memberChk' name="category[]" value="social">Social Networking&nbsp&nbsp</label>
        <label> <input type="checkbox" class='memberChk' name="category[]" value="sports">Sports&nbsp&nbsp&nbsp&nbsp&nbsp&nbsp</label>
        <label> <input type="checkbox" class='memberChk' name="category[]" value="sticker">Sticker&nbsp&nbsp&nbsp&nbsp&nbsp&nbsp<br></label>
        <label> <input type="checkbox" class='memberChk' name="category[]" value="travel">Travel&nbsp&nbsp&nbsp&nbsp&nbsp&nbsp&nbsp</label>
        <label> <input type="checkbox" class='memberChk' name="category[]" value="utility">Utility&nbsp&nbsp&nbsp&nbsp&nbsp</label>
        <label> <input type="checkbox" class='memberChk' name="category[]" value="weather">Weather&nbsp&nbsp&nbsp&nbsp&nbsp&nbsp&nbsp</label>
       <input type="submit" value="OK">
       </fieldset>
     </td>
   </tr>
 </table>
   </form>
</div>
<br>

<script>
    var selectAll = document.querySelector(".selectAllMembers");
     selectAll.addEventListener('click', function(){
         var objs = document.querySelectorAll(".memberChk");
         for (var i = 0; i < objs.length; i++) {
           objs[i].checked = selectAll.checked;
         };
     }, false);
      
     var objs = document.querySelectorAll(".memberChk");
     for(var i=0; i<objs.length ; i++){
       objs[i].addEventListener('click', function(){
         var selectAll = document.querySelector(".selectAllMembers");
         for (var j = 0; j < objs.length; j++) {
           if (objs[j].checked === false) {
             selectAll.checked = false;
             return;
           };
         };
         selectAll.checked = true;                                   
     }, false);
     } 

   </script>

<?php
   $q = $_POST["category"];
   $length=count($q);
   $hostname = 'localhost';
   $username = 'root';
   $pw = 'root';
   $db = 'projectDB';

   $conn = new mysqli($hostname, $username, $pw, $db);
   if($conn -> connect_error){
      echo "die";
        die("Connection failed: ". $conn->connect_error);
   }


   // content rating 
   $stack_4=array();
   $stack_9=array();
   $stack_12=array();
   $stack_17=array();
   for($count=0;$count<$length;$count++){
       $sql_4="SELECT count(*) FROM {$q[$count]} WHERE content_rating='4+'";
       $data_4=$conn->query($sql_4);
       $sum_4=mysqli_fetch_array($data_4);
       $sql_9="SELECT count(*) FROM {$q[$count]} WHERE content_rating='9+'";
       $data_9=$conn->query($sql_9);
       $sum_9=mysqli_fetch_array($data_9);
       $sql_12="SELECT count(*) FROM {$q[$count]} WHERE content_rating='12+'";
       $data_12=$conn->query($sql_12);
       $sum_12=mysqli_fetch_array($data_12);
       $sql_17="SELECT count(*) FROM {$q[$count]} WHERE content_rating='17+'";
       $data_17=$conn->query($sql_17);
       $sum_17=mysqli_fetch_array($data_17);

       if($sum_4[0] != 0 || $sum_9[0] != 0 || $sum_12[0] != 0 || $sum_17[0] != 0){
          $arr_tmp_4=array();
          $arr_tmp_4['y']=$sum_4[0];
          $arr_tmp_4['label']=$q[$count];
          array_push($stack_4,$arr_tmp_4);
          $arr_tmp_9=array();
          $arr_tmp_9['y']=$sum_9[0];
          $arr_tmp_9['label']=$q[$count];
          array_push($stack_9,$arr_tmp_9);
          $arr_tmp_12=array();
          $arr_tmp_12['y']=$sum_12[0];
          $arr_tmp_12['label']=$q[$count];
          array_push($stack_12,$arr_tmp_12);
          $arr_tmp_17=array();
          $arr_tmp_17['y']=$sum_17[0];
          $arr_tmp_17['label']=$q[$count];
          array_push($stack_17,$arr_tmp_17);
      }
   }


   // 여기부터 query 생성 -    review-rating line graph
    $line_data_rating = array();
    $line_data_review = array();
    for ($count=0; $count<$length; $count++){
        $sql = "SELECT avg(rating), sum(review) FROM {$q[$count]} WHERE rating !=0";
        $data = $conn->query($sql);
        $row = mysqli_fetch_array($data);
        if ($row[0] != 0){
           $arr_tmp = array();
           $arr_tmp['label'] = $q[$count];
           $arr_tmp['y'] = $row[0]; //rating
           array_push($line_data_rating, $arr_tmp);
          $arr_tmp = array();
           $arr_tmp['label'] = $q[$count];
           $arr_tmp['y'] = $row[1]; //review
           array_push($line_data_review, $arr_tmp); 
       }   
    }

   //여기서부터 query 생성 - free-paid review 개수
   $bar_data_f=array();
   $bar_data_p=array();
   $bar_data_review_shrink = array();
   for($count=0;$count<$length;$count++){
       $sql_rf="SELECT sum(review) FROM {$q[$count]} WHERE price='free'";
       $data_rf=$conn->query($sql_rf);
       $sum_rf=mysqli_fetch_array($data_rf);
       $sql_rp="SELECT sum(review) FROM {$q[$count]} WHERE price='paid'";
       $data_rp=$conn->query($sql_rp);
       $sum_rp=mysqli_fetch_array($data_rp);
      if ($sum_rf[0] != 0){
          $arr_tmp_f=array();
          $arr_tmp_p=array();
          $arr_tmp_f['y']=$sum_rf[0];
          $arr_tmp_f['label']=$q[$count];
          $arr_tmp_p['y']=$sum_rp[0];
          $arr_tmp_p['label']=$q[$count];
          array_push($bar_data_f,$arr_tmp_f);
          array_push($bar_data_p,$arr_tmp_p);
            array_push($bar_data_review_shrink, $sum_rf[0]);
          array_push($bar_data_review_shrink, $sum_rp[0]);
      }
   }

   //free -paid number bar chart
   $bar_data_z=array();
   $bar_data_nz=array();
   $bar_data_number_shrink = array();
   for($count=0;$count<$length;$count++){
       $sql_z="SELECT count(*) FROM {$q[$count]} WHERE price='free'";
       $data_z=$conn->query($sql_z);
       $row_z=mysqli_fetch_array($data_z);
       if ($row_z[0] != 0){
          $sql_t="SELECT count(*) FROM {$q[$count]}";
          $data_t=$conn->query($sql_t);
          $row_t=mysqli_fetch_array($data_t);
          $arr_tmp=array();
          $arr_tmp_n=array();
          $arr_tmp['y']=$row_z[0];
          $arr_tmp['label']=$q[$count];
          $arr_tmp_n['y']=$row_t[0]-$row_z[0];
          $arr_tmp_n['label']=$q[$count];
          array_push($bar_data_z,$arr_tmp);
          array_push($bar_data_nz,$arr_tmp_n);
          array_push($bar_data_number_shrink, $row_z[0]);
          array_push($bar_data_number_shrink, $row_t[0]-$row_z[0]);
      }
   }


   function Quartile($Array, $Quartile) {
        sort($Array);
        $pos = (count($Array) - 1) * $Quartile;
        $base = floor($pos);
        $rest = $pos - $base;
        if( isset($Array[$base+1]) ) {
          return $Array[$base] + $rest * ($Array[$base+1] - $Array[$base]);
        } else {
          return $Array[$base];
        }
      }
      $top_review_bar = Quartile($bar_data_review_shrink, 0.95);
      $bottom_review_bar = Quartile($bar_data_review_shrink, 0.85);
      $top_number_bar = Quartile($bar_data_number_shrink, 0.95);
      $bottom_number_bar = Quartile($bar_data_number_shrink, 0.85);
      //echo "<br> bar top: ".$top_review_bar. " bottom: ".$bottom_review_bar; //디버깅
   $conn->close();
?>

<script>
window.onload = function () {
   var chart_stack = new CanvasJS.Chart("chart_stack",{
      animationEnabled: true,
      title:{
          text: "Percentage of Content Rating"
          },
          toolTip: {
              shared: true
              },
          axisY:{
              title: "Percentage"
                  },
          data:[{
              type: "stackedBar100",
              showInLegend: true,
              name: "4+",
              dataPoints: <?php echo json_encode($stack_4, JSON_NUMERIC_CHECK); ?>
              },
              {
              type: "stackedBar100",
              showInLegend: true,
              name: "9+",
              dataPoints: <?php echo json_encode($stack_9, JSON_NUMERIC_CHECK); ?>
              },
              {
              type: "stackedBar100",
              showInLegend: true,
              name: "12+",
              dataPoints: <?php echo json_encode($stack_12, JSON_NUMERIC_CHECK); ?>
              },
              {
              type: "stackedBar100",
              showInLegend: true,
              name: "17+",
              dataPoints: <?php echo json_encode($stack_17, JSON_NUMERIC_CHECK); ?>
              }
   ]});

   var chart_line = new CanvasJS.Chart("chartContainer_line", {
      animationEnabled: true,
      title:{
         text: "Average Rating and the Number of Reviews"
      },
      axisY: {
         title: "Average rating",
         includeZero: false
      },
      axisY2:{
         title: "The number of Reviews",
         includeZero: false
      },
      toolTip: {
         shared: true
      },
      legend: {
         cursor: "pointer",
         itemclick: toggleDataSeries
      },
      data: [{
         type: "line",
         color: "#F08080",
         axisYindex:0,
         showInLegend: true,
         name: "Rating",
         dataPoints: <?php echo json_encode($line_data_rating, JSON_NUMERIC_CHECK); ?>
      },
      {
         type: "line",
         color: "#129EF7",
         axisYType: "secondary",
         showInLegend: true,
         name: "Review",
         dataPoints: <?php echo json_encode($line_data_review, JSON_NUMERIC_CHECK); ?>
      }
      ]
   });

   var bar_chart_r = new CanvasJS.Chart("bar_chart_r", {
        animationEnabled: true,
        theme: "light1", // "light1", "light2", "dark1", "dark2"
        title: {
            text: "The Number of Reviews for Paid and Free App"
        },
        axisY: {
           scaleBreaks: {
              customBreaks:[{
                  startValue: <?php echo json_encode($bottom_review_bar, JSON_NUMERIC_CHECK); ?>,
                  endValue: <?php echo json_encode($top_review_bar, JSON_NUMERIC_CHECK); ?>
               }]
           },
            title: "total number"
        },
        data: [{
            type: "column",
            showInLegend: true,
         name: "Free",
            dataPoints: <?php echo json_encode($bar_data_f, JSON_NUMERIC_CHECK); ?>
        },
        {
            type:"column",
            showInLegend: true,
         name: "Paid",
            dataPoints:<?php echo json_encode($bar_data_p, JSON_NUMERIC_CHECK); ?>
        }]
    });

   //z bar chart
    var z_bar_chart = new CanvasJS.Chart("z_bar_chartContainer", {
       animationEnabled: true,
       theme: "light2", // "light1", "light2", "dark1", "dark2"
       title: {
           text: "The number of Paid and Free App"
       },
       axisY: {
          scaleBreaks: {
              customBreaks:[{
                  startValue: <?php echo json_encode($bottom_number_bar, JSON_NUMERIC_CHECK); ?>,
                  endValue: <?php echo json_encode($top_number_bar, JSON_NUMERIC_CHECK); ?>
               }]
           },
           title: "The Number of App"
       },
       data: [{
           type: "column",
            showInLegend: true,
         name: "Free",
           dataPoints: <?php echo json_encode($bar_data_z, JSON_NUMERIC_CHECK); ?>
       },
       {
           type:"column",
           showInLegend: true,
         name: "Paid",
           dataPoints:<?php echo json_encode($bar_data_nz, JSON_NUMERIC_CHECK); ?>
       }]
   });

   chart_line.render();
   chart_stack.render();
   bar_chart_r.render();
    z_bar_chart.render();


   function toggleDataSeries(e) {
      if (typeof (e.dataSeries.visible) === "undefined" || e.dataSeries.visible) {
         e.dataSeries.visible = false;
      } else {
         e.dataSeries.visible = true;
      }
      e.chart_line.render();
   }
   function toolTipFormatter(e) {
      var str = "";
      var total = 0 ;
      var str3;
      var str2 ;
      for (var i = 0; i < e.entries.length; i++){
         var str1 = "<span style= \"color:"+e.entries[i].dataSeries.color + "\">" + e.entries[i].dataSeries.name + "</span>: <strong>"+  e.entries[i].dataPoint.y + "</strong> <br/>" ;
         total = e.entries[i].dataPoint.y + total;
         str = str.concat(str1);
      }
      str2 = "<strong>" + e.entries[0].dataPoint.label + "</strong> <br/>";
      str3 = "<span style = \"color:Tomato\">Total: </span><strong>" + total + "</strong><br/>";
      return (str2.concat(str)).concat(str3);
   }

}
</script>

<script src="https://canvasjs.com/assets/script/canvasjs.min.js"></script>
<div id="chartContainer_line" style="height: 600px; width: 100%;"></div>
<div id="chart_stack" style="height: 600px; width: 100%;"></div><Br><br>
<div id="bar_chart_r" style="height: 600px; width: 100%;"></div>
<div id="z_bar_chartContainer" style="height: 600px; width: 100%;"></div>
</body>
</html>